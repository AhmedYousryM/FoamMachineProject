#include "Useable.h"
uint16_t RFVariable[500]={101,102,103};