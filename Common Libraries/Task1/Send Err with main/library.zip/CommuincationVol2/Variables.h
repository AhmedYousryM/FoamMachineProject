#ifndef VARIABLES_H
#define VARIABLES_H
#include "Useable.h"

Variable GlobalVariable[100]={}; // 7
Variable CFVariable[100]={}; // 1
Variable CRVariable[100]={}; // 2
Variable CMVariable[100]={}; // 3
Variable RFVariable[100]={}; // 4
Variable RMVariable[100]={}; // 5
Variable FMVariable[100]={}; // 6
Variable ErrorVariable[105]={};
#endif

