#ifndef COMM_H
#define COMM_H
void SendMessage();
#endif