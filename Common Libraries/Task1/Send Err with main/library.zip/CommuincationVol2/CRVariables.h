#include "Useable.h"
uint16_t CRVariable[500]={101,102,103};