#include "Useable.h"
uint16_t CMVariable[500]={101,102,103};