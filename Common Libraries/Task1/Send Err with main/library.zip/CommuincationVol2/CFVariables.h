#include "Useable.h"
uint16_t CFVariable[500]={101,102,103};
