#include "Variables.h";
uint16_t GlobalVariable[500]={501,502,503};